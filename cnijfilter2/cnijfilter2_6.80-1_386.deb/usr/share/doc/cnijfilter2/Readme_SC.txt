﻿附录

以下是该驱动程序所含许可模块的列表。

附件 1（该驱动程序的软件程序）


libcnbpcmcm*.so.?.?.?
libcnbpcnclapi*.so. ?.?.?
libcnbpcnclbjcmd*.so.?.?.?
libcnbpcnclui*.so.?.?.?
libcnbpess*.so.?.?.?
libcnbpo*.so.?.?.?
libcnbpnet20.so.?.?.?
libcnbpnet30.so.?.?.?
libcnnet*.so.?.?.?
cnnet.ini
cif*.conf
cnb_*0.tbl
cnbpname*.tbl
nozl_*.utl
regi_*.utl
cif_*.bscc
*.xpm
printui.res
*_ps
*_raw
cnij_entry_*series
cnij_entry
cnb_*.res
81-canonij_prn.rules
maintenance.res
autoalign.utl
cleaning.utl
nozzlecheck.utl
cnijlgmon2.res


附件 2（GNU General Public License Version 2许可的免费软件组件）


cngpij
pstocanonij
cnij_usb
cnijusb
cnijnet
cnij_parallel
cngpijmon*
lgmon*(Ver.2.60-Ver.3.1*)
printui*.mo
cngpijmon*.mo
printui.glade
*.ppd
locale-table
stsmon*
ijcmd*
stsmon*.mo
cnijfilter-*-pkgconfig.sh
cnijfilter2-*-pkgconfig.sh
printer_*.lc
cngpijmnt
maintenance*.mo
maintenance.glade
cnijbe*
cmdtocanonij
cnijlgmon2.mo
cnijlgmon3.mo
rastertocanonij
tocnpwg


附件 3


printui*
cif*
cnijnetprn
cnijnpr
lgmon*(Ver.3.20-)
maintenance*
cnijlgmon2
cnijlgmon3
cmdtocanonij2
cmdtocanonij3
tocanonij
